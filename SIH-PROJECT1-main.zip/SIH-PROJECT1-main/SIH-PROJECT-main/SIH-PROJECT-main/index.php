<?php

header("location:shared/login.html");
?>