<?php

$conn = new mysqli("localhost","root","","gradaim",3307);

?>